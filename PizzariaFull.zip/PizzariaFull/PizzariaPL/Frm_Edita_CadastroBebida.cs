﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PizzariaBLL;
using PizzariaDTO;
namespace PizzariaPL
{
    public partial class Frm_Edita_CadastroBebida : Form
    {
        public CadastroBebidaDTO Bebida;

        public Frm_Edita_CadastroBebida(int CodigoBebida)
        {
            InitializeComponent();

            if(CodigoBebida != 0)
                {
              Bebida =   CadastroBebidaBLL.PesquisaBebida(CodigoBebida);

                txtNome.Text = Bebida.Nome.ToString();
                txtValor.Text = Bebida.Valor.ToString();


                }

        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            if(Bebida != null)
            {
                Bebida.Nome = txtNome.Text;
                Bebida.Valor = float.Parse(txtValor.Text);

                CadastroBebidaBLL.Updatebebida(Bebida);

                DialogResult = DialogResult.OK;

                this.Close();


            }
        }
    }
}
