﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PizzariaBLL;
using PizzariaDTO;



namespace PizzariaPL
{
    public partial class Frm_CadastroBebida : Form
    {
        public CadastroBebidaDTO Cadastro = new CadastroBebidaDTO();
        public Frm_CadastroBebida()
        {
            InitializeComponent();
        }

        private void Frm_CadastroBebida_Load(object sender, EventArgs e)
        {

        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            CadastroBebidaDTO objCadastro = new CadastroBebidaDTO();

            objCadastro.Nome = txtNome.Text;
            objCadastro.Valor = float.Parse(txtValor.Text);

            CadastroBebidaBLL.InserirProduto(objCadastro);

           


        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            List<CadastroBebidaDTO> Atualiza = CadastroBebidaBLL.AtualizaLista();

            dgvBebida.Rows.Clear();

            foreach (var objCadastro in Atualiza)
            {
                string[] LinhaAtualiza = { objCadastro.Id.ToString(), objCadastro.Nome.ToString(), objCadastro.Valor.ToString() };


                dgvBebida.Rows.Add(LinhaAtualiza);

            }

        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
           if(MessageBox.Show("Deseja Excluir a bebida selecionada?", "Exclusão", MessageBoxButtons.YesNo,MessageBoxIcon.Question) == DialogResult.Yes)
            {

                int LinhaExclusao = int.Parse(dgvBebida.CurrentRow.Cells["ColumnID"].Value.ToString());

                CadastroBebidaBLL.ExclusaoBebida(LinhaExclusao);

                dgvBebida.Rows.RemoveAt(dgvBebida.CurrentRow.Index);




            }



            }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            int LinhaBebida = int.Parse(dgvBebida.CurrentRow.Cells["ColumnID"].Value.ToString());

            Frm_Edita_CadastroBebida Form_Bebida = new Frm_Edita_CadastroBebida(LinhaBebida);

            var result = Form_Bebida.ShowDialog();

            if (result == DialogResult.OK)
            {


                string[] LinhaAtualizaBebida = { Form_Bebida.Bebida.Id.ToString(), Form_Bebida.Bebida.Nome.ToString(), Form_Bebida.Bebida.Valor.ToString() };

                dgvBebida.Rows[dgvBebida.CurrentRow.Index].SetValues(LinhaAtualizaBebida);

            }
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            Cadastro.Nome = dgvBebida.CurrentRow.Cells["ColumnNome"].Value.ToString();
            Cadastro.Valor = float.Parse(dgvBebida.CurrentRow.Cells["ColumnValor"].Value.ToString());


            DialogResult = DialogResult.OK;
        }
    }
    }

