﻿using System;


using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PizzariaBLL;
using PizzariaDTO;
namespace PizzariaPL
{
    public partial class Frm_Edita_CadastroPizza : Form
    {
        public CadastroPizzaDTO Pizza;
        public Frm_Edita_CadastroPizza(int codigoPizza)
        {
            
            InitializeComponent();

            if(codigoPizza != 0)

            {

              Pizza =   CadastroPizzaBLL.PesquisaPizza(codigoPizza);

                txtProduto.Text = Pizza.Nome.ToString();
                txtValor.Text = Pizza.Valor.ToString();


            }

            


            
        }

        private void Salvar_Click(object sender, EventArgs e)
        {
            if(Pizza != null)
            {
                Pizza.Nome = txtProduto.Text;
                Pizza.Valor = float.Parse(txtValor.Text);



                
                CadastroPizzaBLL.UpdatePizza(Pizza);

                MessageBox.Show("Pizza atualizada com sucesso!", "Atualiza Pizza", MessageBoxButtons.OK, MessageBoxIcon.Information);


                DialogResult = DialogResult.OK;

                this.Hide();


            }
        }
    }
}
