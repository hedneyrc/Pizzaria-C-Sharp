﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PizzariaBLL;
using PizzariaDTO;

namespace PizzariaPL
{
    public partial class Frm_Pedido : Form
    {
        float Valor_Final = 0;
        public Frm_Pedido( )
        {
            
            InitializeComponent();
            
            

        }

        private void Frm_Pedido_Load(object sender, EventArgs e)
        {
            txtNome.Enabled = false;
            txtTelefone.Enabled = false;
            txtEndereco.Enabled = false;
            txtPizza.Enabled = false;
            txtBebida.Enabled = false;
            txtValorBebida.Enabled = false;
            txtValorPizza.Enabled = false;
            txtValorFinal.Enabled = false;


            txtValorBebida.Text = "0";
            txtValorPizza.Text = "0";

            







        }

        private void toolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {

            Frm_CadastroCliente Form_Cliente = new Frm_CadastroCliente();

            
            var retorno = Form_Cliente.ShowDialog();

            if (retorno == DialogResult.OK)
            {

                txtNome.Text = Form_Cliente.Cadastro.Nome.ToString();
                txtEndereco.Text = Form_Cliente.Cadastro.Endereco.ToString();
                txtTelefone.Text = Form_Cliente.Cadastro.Telefone.ToString();


            }






        }

        public void txtNomePedido_TextChanged(object sender, EventArgs e)
        {

        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            Frm_CadastroPizza Form_Pizza = new Frm_CadastroPizza();


            var retorno = Form_Pizza.ShowDialog();

            if (retorno == DialogResult.OK)
            {

                txtPizza.Text = Form_Pizza.Cadastro.Nome.ToString();
                txtValorPizza.Text= Form_Pizza.Cadastro.Valor.ToString();
               


            }
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            Frm_CadastroBebida Form_Bebida = new Frm_CadastroBebida();


            var retorno = Form_Bebida.ShowDialog();

            if (retorno == DialogResult.OK)
            {

                txtBebida.Text = Form_Bebida.Cadastro.Nome.ToString();
                txtValorBebida.Text = Form_Bebida.Cadastro.Valor.ToString();


            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
          
            Valor_Final = float.Parse(txtValorBebida.Text) + float.Parse(txtValorPizza.Text);
            txtValorFinal.Text = Valor_Final.ToString();

        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            CadastroPedidoDTO objCadastro = new CadastroPedidoDTO();

            objCadastro.NomePedido = txtNome.Text;
            objCadastro.TelefonePedido = txtTelefone.Text;
            objCadastro.EnderecoPedido = txtEndereco.Text;
            objCadastro.NomePizza = txtPizza.Text;
            objCadastro.NomeBebida = txtBebida.Text;
            objCadastro.ValorPizza = float.Parse(txtValorPizza.Text);
            objCadastro.ValorBebida = float.Parse(txtValorBebida.Text);
            objCadastro.ValorFinal = float.Parse(txtValorFinal.Text);

            CadastroPedidoBLL.InserirPedido(objCadastro);

            List<CadastroPedidoDTO> AtualizaPedido = CadastroPedidoBLL.AtualizaPedido();

            dgvPedido.Rows.Clear();

            foreach (var objPedido in AtualizaPedido)
            {

                string[] LinhaAtualiza = { objPedido.NomePedido.ToString(), objPedido.TelefonePedido.ToString(), objPedido.EnderecoPedido.ToString(), objPedido.NomePizza.ToString(), objPedido.ValorPizza.ToString(), objPedido.NomeBebida.ToString(), objPedido.ValorBebida.ToString(), objPedido.ValorFinal.ToString() };

                dgvPedido.Rows.Add(LinhaAtualiza);



            }

            txtNome.Text = "";
            txtTelefone.Text = "";
            txtEndereco.Text = "";
            txtPizza.Text = "";
            txtBebida.Text = "";
            txtValorPizza.Text = "0";
            txtValorBebida.Text = "0";
            txtValorFinal.Text = "0";

        }

        private void button2_Click(object sender, EventArgs e)
        {

            List<CadastroPedidoDTO> AtualizaPedido = CadastroPedidoBLL.AtualizaPedido();
            
            dgvPedido.Rows.Clear();

            foreach(var objPedido in AtualizaPedido)
            {

                string[] LinhaAtualiza={ objPedido.NomePedido.ToString(), objPedido.TelefonePedido.ToString(), objPedido.EnderecoPedido.ToString(), objPedido.NomePizza.ToString(), objPedido.ValorPizza.ToString(), objPedido.NomeBebida.ToString(), objPedido.ValorBebida.ToString(), objPedido.ValorFinal.ToString() };

                dgvPedido.Rows.Add(LinhaAtualiza);



            }



        }
    }
}
