﻿using System;

using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PizzariaBLL;
using PizzariaDTO;


namespace PizzariaPL
{
   


    public partial class Frm_CadastroCliente : Form
    {
        public CadastroClienteDTO Cadastro = new CadastroClienteDTO();
        

        public Frm_CadastroCliente()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Frm_Pedido Pedido = new Frm_Pedido();
            Pedido.Close();


        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            CadastroClienteDTO objCadastro = new CadastroClienteDTO();

            objCadastro.Nome = txtNome.Text;
            objCadastro.Telefone = txtTelefone.Text;
            objCadastro.Endereco = txtEndereco.Text;

            CadastroClienteBLL.InserirCadastroCliente(objCadastro);

            MessageBox.Show("Cadastro Inserido!!");

            txtNome.Text = "";
            txtEndereco.Text = "";
            txtTelefone.Text = "";




        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {



            if (MessageBox.Show("Deseja realmente excluir o Cliente?", "Exclusão Cliente", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                int LinhaExclusao = int.Parse(dvgCliente.CurrentRow.Cells["ColumnID"].Value.ToString());

                CadastroClienteBLL.ExclusaoCliente(LinhaExclusao);

                dvgCliente.Rows.RemoveAt(dvgCliente.CurrentRow.Index);

            }
        }

        public void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            List<CadastroClienteDTO> Busca = CadastroClienteBLL.BuscaCLiente();

            dvgCliente.Rows.Clear();

            foreach (var objBusca in Busca)
            {

                string[] LinhaBusca = { objBusca.Id.ToString(), objBusca.Nome.ToString(), objBusca.Telefone.ToString(), objBusca.Endereco.ToString() };

                dvgCliente.Rows.Add(LinhaBusca);

            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Frm_CadastroPizza Form_Produto = new Frm_CadastroPizza();
            Form_Produto.Show();
            this.Hide();






        }

        private void button2_Click(object sender, EventArgs e)
        {
            Frm_CadastroBebida Form_Bebida = new Frm_CadastroBebida();
            Form_Bebida.Show();
            this.Hide();



        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            int EditaLinhaCliente = int.Parse(dvgCliente.CurrentRow.Cells["ColumnID"].Value.ToString());

            Frm_Edita_CadastroCliente Form_EditaCliente = new Frm_Edita_CadastroCliente(EditaLinhaCliente);

            var result = Form_EditaCliente.ShowDialog();

            if (result == DialogResult.OK)
            {

                string[] LinhaCliente = { Form_EditaCliente.Cliente.Id.ToString(), Form_EditaCliente.Cliente.Nome.ToString(), Form_EditaCliente.Cliente.Telefone.ToString(), Form_EditaCliente.Cliente.Endereco.ToString() };

                dvgCliente.Rows[dvgCliente.CurrentRow.Index].SetValues(LinhaCliente);

            }


        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
           

        Cadastro.Nome = dvgCliente.CurrentRow.Cells["ColumnNome"].Value.ToString();
        Cadastro.Endereco = dvgCliente.CurrentRow.Cells["ColumnEndereco"].Value.ToString();
        Cadastro.Telefone = dvgCliente.CurrentRow.Cells["ColumnTelefone"].Value.ToString();


            DialogResult = DialogResult.OK;

                                                                           
        }


        
    }

}