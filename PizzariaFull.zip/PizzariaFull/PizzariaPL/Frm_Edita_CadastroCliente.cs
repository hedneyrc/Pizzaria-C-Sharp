﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PizzariaBLL;
using PizzariaDTO;

namespace PizzariaPL
{
    public partial class Frm_Edita_CadastroCliente : Form
    {
        public CadastroClienteDTO Cliente;

        

        public Frm_Edita_CadastroCliente(int CodigoCliente)
        {
            InitializeComponent();
            Cliente.Nome = "";
            Cliente.Telefone = "";
            Cliente.Endereco = "";

            if (CodigoCliente !=0)
            {
                Cliente = CadastroClienteBLL.PesquisaCliente(CodigoCliente);


                txtNome.Text = Cliente.Nome.ToString();
                txtTelefone.Text = Cliente.Telefone.ToString();
                txtEndereco.Text = Cliente.Endereco.ToString();
                                             
            }
        }

       public void toolStripButton1_Click(object sender, EventArgs e)
        {
            Cliente.Nome = txtNome.Text;
            Cliente.Telefone = txtTelefone.Text;
            Cliente.Endereco = txtEndereco.Text;



            CadastroClienteBLL.UpdateCliente(Cliente);

            MessageBox.Show("Cadastro Atualizado com Sucesso!","Aviso",MessageBoxButtons.OK,MessageBoxIcon.Question);

            DialogResult = DialogResult.OK;




            this.Close();




        }

        private void Frm_Edita_CadastroCliente_Load(object sender, EventArgs e)
        {
           
        }
    }
}
