﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PizzariaBLL;
using PizzariaDTO;


namespace PizzariaPL
{
    public partial class Frm_CadastroPizza : Form
    {
       public CadastroPizzaDTO Cadastro = new CadastroPizzaDTO();

        public Frm_CadastroPizza()
        {
            InitializeComponent();
        }

        private void Frm_CadastroProduto_Load(object sender, EventArgs e)
        {
            

        }

        private void Incluir_Click(object sender, EventArgs e)
        {
            CadastroPizzaDTO objCadastro = new CadastroPizzaDTO();
            objCadastro.Nome = txtNome.Text;
            objCadastro.Valor =float.Parse( txtValor.Text);
            

            CadastroPizzaBLL.InserirProduto(objCadastro);

        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            List<CadastroPizzaDTO> Atualiza = CadastroPizzaBLL.AtualizaLista();

            dvgPizza.Rows.Clear();

            foreach(var objCadastro in Atualiza)
            {
                string[] LinhaAtualiza = {objCadastro.Id.ToString(), objCadastro.Nome.ToString(), objCadastro.Valor.ToString() };

                dvgPizza.Rows.Add(LinhaAtualiza);

            }
        }

        private void Excluir_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("Deseja realmente excluir a Pizza?", "Exclusão Pizza", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {

                int LinhaExclusao = int.Parse(dvgPizza.CurrentRow.Cells["ColumnID"].Value.ToString());

                CadastroPizzaBLL.ExclusaoPizza(LinhaExclusao);

                dvgPizza.Rows.RemoveAt(dvgPizza.CurrentRow.Index);

                

            }
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            int LinhaProduto = int.Parse(dvgPizza.CurrentRow.Cells["ColumnID"].Value.ToString());

            Frm_Edita_CadastroPizza Form_EditaCadastroPizza = new Frm_Edita_CadastroPizza(LinhaProduto);

            var result = Form_EditaCadastroPizza.ShowDialog();

            if (result == DialogResult.OK)
            {


                string[] LPizza = { Form_EditaCadastroPizza.Pizza.Id.ToString(), Form_EditaCadastroPizza.Pizza.Nome.ToString(), Form_EditaCadastroPizza.Pizza.Valor.ToString() };

                dvgPizza.Rows[dvgPizza.CurrentRow.Index].SetValues(LPizza);

            }



        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            Cadastro.Nome = dvgPizza.CurrentRow.Cells["ColumnProduto"].Value.ToString();
            Cadastro.Valor = float.Parse(dvgPizza.CurrentRow.Cells["ColumnValor"].Value.ToString());


            DialogResult = DialogResult.OK;
        }
    }
}
