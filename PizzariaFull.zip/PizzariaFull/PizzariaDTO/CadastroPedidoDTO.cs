﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzariaDTO
{
    public class CadastroPedidoDTO
    {
        public string NomePedido { get; set; }
        public string EnderecoPedido { get; set; }
        public string TelefonePedido { get; set; }
        public string NomePizza { get; set; }
        public string NomeBebida { get; set; }
        public float ValorBebida { get; set; }
        public float ValorPizza { get; set; }
        public float ValorFinal { get; set; }


    }
}
