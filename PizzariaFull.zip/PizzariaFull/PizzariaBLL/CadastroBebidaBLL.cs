﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PizzariaDal;
using PizzariaDTO;


namespace PizzariaBLL
{
    public class CadastroBebidaBLL
    {

        public static int InserirProduto(CadastroBebidaDTO objCadastro)
        {

            return CadastroBebidaDal.InserirProduto(objCadastro);


        }

        public static List<CadastroBebidaDTO>AtualizaLista()
        {

            return CadastroBebidaDal.AtualizaLista();



      
        }

        public static int ExclusaoBebida (int objExclusao)
        {

            return CadastroBebidaDal.ExclusaoBebida(objExclusao);

        }

        public static CadastroBebidaDTO PesquisaBebida(int codigoBebida)
        {

            return CadastroBebidaDal.PesquisaBebida(codigoBebida);
        }

        public static void Updatebebida(CadastroBebidaDTO CodigoBebida)
        {

            CadastroBebidaDal.Updatebebida(CodigoBebida);
        }

    }
}
