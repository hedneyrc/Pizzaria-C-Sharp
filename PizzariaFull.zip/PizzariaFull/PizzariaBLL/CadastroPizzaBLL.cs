﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PizzariaDal;
using PizzariaDTO;


namespace PizzariaBLL
{
    public class CadastroPizzaBLL
    {
        public static int InserirProduto(CadastroPizzaDTO objCadastro)
        {

            return CadastroPizzaDal.InserirProduto(objCadastro);

        }

        public static List<CadastroPizzaDTO> AtualizaLista()
        {

            return CadastroPizzaDal.AtualizaLista();

        }

        public static int ExclusaoPizza (int objExclusao)
        {

            return CadastroPizzaDal.ExclusaoPizza(objExclusao);

        }


        public static CadastroPizzaDTO PesquisaPizza(int CodigoPizza)


        {
            return CadastroPizzaDal.PesquisaPizza(CodigoPizza);
            
        }


        public static void UpdatePizza(CadastroPizzaDTO CodigoPizza)

        {

            CadastroPizzaDal.UpdatePizza(CodigoPizza);


        }

    }
}
