﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PizzariaDal;
using PizzariaDTO;


namespace PizzariaBLL
{
    public class CadastroClienteBLL
    {

        public static int InserirCadastroCliente(CadastroClienteDTO objCadastro)
        {

            return CadastroClienteDal.InserirCadastroCliente(objCadastro);

        }


        public static List<CadastroClienteDTO> BuscaCLiente()
        {

            return CadastroClienteDal.BuscaCLiente();

        }

        public static int ExclusaoCliente (int objExclusao)
        {

            return CadastroClienteDal.ExclusaoCliente(objExclusao);

        }

        public static CadastroClienteDTO PesquisaCliente(int CodigoCliente)
        {

            return CadastroClienteDal.PesquisaCliente(CodigoCliente);
        }

        public static void UpdateCliente(CadastroClienteDTO objCadastro)
        {

            CadastroClienteDal.UpdateCliente(objCadastro);

        }
    }
}
