﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PizzariaDal;
using PizzariaDTO;

namespace PizzariaBLL
{
    public class CadastroPedidoBLL
    {

        public static int InserirPedido(CadastroPedidoDTO objCadastro)
        {


            return CadastroPedidoDal.InserirPedido(objCadastro);

        }


        public static List<CadastroPedidoDTO> AtualizaPedido()
        {

            return CadastroPedidoDal.AtualizaPedido();

        }

    }
}
