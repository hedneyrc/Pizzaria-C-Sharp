﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PizzariaDTO;
using System.Data.SqlClient;
using System.Data;




namespace PizzariaDal
{
    public class CadastroClienteDal
    {

        public static int InserirCadastroCliente(CadastroClienteDTO objCadastro)
        {
            SqlConnection conexao = new SqlConnection();
            conexao.ConnectionString = PizzariaDal.Properties.Settings.Default.ConexaoBD;
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexao;
            comando.CommandText = "Insert TB_CLIENTE(NM_CLIENTE,TEL_CLIENTE,END_CLIENTE) values (@Nome,@Telefone,@Endereco)";


            comando.Parameters.Add("Nome", SqlDbType.VarChar).Value = objCadastro.Nome;
            comando.Parameters.Add("Telefone", SqlDbType.VarChar).Value = objCadastro.Telefone;
            comando.Parameters.Add("Endereco", SqlDbType.VarChar).Value = objCadastro.Endereco;

            conexao.Open();





            return comando.ExecuteNonQuery();





        }

        public static List<CadastroClienteDTO> BuscaCLiente()
        {
            SqlConnection conexao = new SqlConnection();
            conexao.ConnectionString= PizzariaDal.Properties.Settings.Default.ConexaoBD;
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexao;

            comando.CommandText = "Select ID_CLIENTE, NM_CLIENTE, TEL_CLIENTE, END_CLIENTE FROM TB_CLIENTE";
            conexao.Open();

                        SqlDataReader DR = comando.ExecuteReader();

            List<CadastroClienteDTO> Cadastro = new List<CadastroClienteDTO>();

            if(DR.HasRows)
            {
                while(DR.Read())
                {
                    CadastroClienteDTO objCadastro = new CadastroClienteDTO();

                    objCadastro.Nome = Convert.ToString(DR["NM_CLIENTE"]);
                    objCadastro.Telefone = Convert.ToString(DR["TEL_cLIENTE"]);
                    objCadastro.Endereco = Convert.ToString(DR["END_CLIENTE"]);
                    objCadastro.Id = Convert.ToInt32(DR["ID_CLIENTE"]);



                    Cadastro.Add(objCadastro);


                }
               
            }
           
            




            




            return Cadastro;


        }


        public static CadastroClienteDTO PesquisaCliente(int CodigoCliente)
        {
            SqlConnection conexao = new SqlConnection();
            conexao.ConnectionString = PizzariaDal.Properties.Settings.Default.ConexaoBD;
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexao;

            comando.CommandText = "Select ID_CLIENTE, NM_CLIENTE, TEL_CLIENTE, END_CLIENTE FROM TB_CLIENTE where ID_CLIENTE = @ID_CLIENTE";
            comando.Parameters.Add("ID_CLIENTE", SqlDbType.VarChar).Value = CodigoCliente;
            conexao.Open();

            SqlDataReader DR = comando.ExecuteReader();

            CadastroClienteDTO objCadastro = new CadastroClienteDTO();

            if (DR.HasRows)
            {
                while (DR.Read())
                {
                   
                    objCadastro.Nome = Convert.ToString(DR["NM_CLIENTE"]);
                    objCadastro.Telefone = Convert.ToString(DR["TEL_cLIENTE"]);
                    objCadastro.Endereco = Convert.ToString(DR["END_CLIENTE"]);
                    objCadastro.Id = Convert.ToInt32(DR["ID_CLIENTE"]);
                }

            }

            return objCadastro;



        }

        public static void UpdateCliente(CadastroClienteDTO objCadastro)
        {
            SqlConnection conexao = new SqlConnection();
            conexao.ConnectionString = PizzariaDal.Properties.Settings.Default.ConexaoBD;
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexao;

            comando.CommandText = "UPDATE TB_CLIENTE SET NM_CLIENTE= @Nome, TEL_CLIENTE= @Telefone, END_CLIENTE= @Endereco  where ID_CLIENTE = @Id";
            comando.Parameters.Add("Id", SqlDbType.VarChar).Value = objCadastro.Id;
            comando.Parameters.Add("Nome", SqlDbType.VarChar).Value = objCadastro.Nome;
            comando.Parameters.Add("Telefone", SqlDbType.VarChar).Value = objCadastro.Telefone;
            comando.Parameters.Add("Endereco", SqlDbType.VarChar).Value = objCadastro.Endereco;

            conexao.Open();

            comando.ExecuteNonQuery();

            
        }

        public static int ExclusaoCliente(int objExclusao)
        {
            SqlConnection conexao = new SqlConnection();
            conexao.ConnectionString = PizzariaDal.Properties.Settings.Default.ConexaoBD;
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexao;
            comando.CommandText = "Delete TB_CLIENTE WHERE ID_CLIENTE = @IdCliente";
            comando.Parameters.Add("IdCliente",SqlDbType.Int).Value=objExclusao;
            conexao.Open();
            return comando.ExecuteNonQuery();

        }
    }
}
