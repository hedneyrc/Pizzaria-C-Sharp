﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PizzariaDTO;

using System.Data.SqlClient;
using System.Data;


namespace PizzariaDal
{
   public  class CadastroBebidaDal
    {

        public static int InserirProduto(CadastroBebidaDTO objCadastro)
        {
            SqlConnection conexao = new SqlConnection();
            conexao.ConnectionString = PizzariaDal.Properties.Settings.Default.ConexaoBD;
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexao;
            comando.CommandText= "Insert TB_BEBIDA(NM_BEBIDA,VL_BEBIDA) values (@Nome,@Valor)";
            comando.Parameters.Add("Nome", SqlDbType.VarChar).Value = objCadastro.Nome;
            comando.Parameters.Add("Valor", SqlDbType.Float).Value = objCadastro.Valor;

            conexao.Open();

            return comando.ExecuteNonQuery();

        }

        public static List<CadastroBebidaDTO> AtualizaLista()
        {
            SqlConnection conexao = new SqlConnection();
            conexao.ConnectionString = PizzariaDal.Properties.Settings.Default.ConexaoBD;
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexao;

            comando.CommandText = "Select ID_BEBIDA,NM_BEBIDA,VL_BEBIDA FROM TB_BEBIDA";

            conexao.Open();

            SqlDataReader DR = comando.ExecuteReader();

            List<CadastroBebidaDTO> Atualiza = new List<CadastroBebidaDTO>();

            if(DR.HasRows)
            {

                while(DR.Read())
                {
                    CadastroBebidaDTO objCadastro = new CadastroBebidaDTO();

                    objCadastro.Nome = Convert.ToString(DR["NM_BEBIDA"]);
                    objCadastro.Valor = Convert.ToSingle(DR["VL_BEBIDA"]);
                    objCadastro.Id = Convert.ToInt16(DR["ID_BEBIDA"]);


                    Atualiza.Add(objCadastro);


                }
            }

            return Atualiza;

        }

        public static int ExclusaoBebida (int objExclusao)
        {

            SqlConnection conexao = new SqlConnection();
            conexao.ConnectionString = conexao.ConnectionString = PizzariaDal.Properties.Settings.Default.ConexaoBD;

            SqlCommand comando = new SqlCommand();
            comando.Connection = conexao;
            comando.CommandText = "DELETE TB_BEBIDA WHERE ID_BEBIDA = @ID_BEBIDA ";
            comando.Parameters.Add("ID_BEBIDA", SqlDbType.Int).Value = objExclusao;

            conexao.Open();

            return comando.ExecuteNonQuery();


        }

        public static CadastroBebidaDTO PesquisaBebida(int codigoBebida)
        {
            SqlConnection conexao = new SqlConnection();
            conexao.ConnectionString = PizzariaDal.Properties.Settings.Default.ConexaoBD;
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexao;

            comando.CommandText = "Select ID_BEBIDA,NM_BEBIDA,VL_BEBIDA FROM TB_BEBIDA WHERE ID_BEBIDA = @Id";
            comando.Parameters.Add("Id", SqlDbType.Int).Value = codigoBebida;


            conexao.Open();

            SqlDataReader DR = comando.ExecuteReader();

            CadastroBebidaDTO objPesquisa = new CadastroBebidaDTO();

            if (DR.HasRows)
            {

                while (DR.Read())
                {


                    objPesquisa.Nome = Convert.ToString(DR["NM_BEBIDA"]);
                    objPesquisa.Valor = Convert.ToSingle(DR["VL_BEBIDA"]);
                    objPesquisa.Id = Convert.ToInt16(DR["ID_BEBIDA"]);


                }
            }

            return objPesquisa;

        }


        public static void Updatebebida(CadastroBebidaDTO CodigoBebida)
        {

            SqlConnection conexao = new SqlConnection();
            conexao.ConnectionString = conexao.ConnectionString = PizzariaDal.Properties.Settings.Default.ConexaoBD;

            SqlCommand comando = new SqlCommand();
            comando.Connection = conexao;
            comando.CommandText = "UPDATE TB_BEBIDA SET NM_BEBIDA = @Nome , VL_BEBIDA = @Valor WHERE ID_BEBIDA = @Id ";
            comando.Parameters.Add("Id", SqlDbType.Int).Value = CodigoBebida.Id;
            comando.Parameters.Add("Nome", SqlDbType.VarChar).Value = CodigoBebida.Nome;
            comando.Parameters.Add("Valor", SqlDbType.Float).Value = CodigoBebida.Valor;

            conexao.Open();

            comando.ExecuteNonQuery();


        }
    }
}
