﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PizzariaDTO;
using System.Data.SqlClient;
using System.Data;



namespace PizzariaDal
{
    public class CadastroPizzaDal
    {

        public static int InserirProduto(CadastroPizzaDTO ObjCdastro)
        {
            SqlConnection conexao = new SqlConnection();
            conexao.ConnectionString = PizzariaDal.Properties.Settings.Default.ConexaoBD;
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexao;
            comando.CommandText = "insert TB_PIZZA(NM_PIZZA,VALOR_PIZZA) values (@Nome, @Valor)";
            comando.Parameters.Add("Nome", SqlDbType.VarChar).Value = ObjCdastro.Nome;
            comando.Parameters.Add("Valor", SqlDbType.Float).Value = ObjCdastro.Valor;

            conexao.Open();






            return comando.ExecuteNonQuery();

        }


        public static List<CadastroPizzaDTO> AtualizaLista()


        {

            SqlConnection conexao = new SqlConnection();
            conexao.ConnectionString= PizzariaDal.Properties.Settings.Default.ConexaoBD;
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexao;
            comando.CommandText = "Select ID_PIZZA, NM_PIZZA,VALOR_PIZZA FROM TB_PIZZA";
            conexao.Open();

            SqlDataReader DR = comando.ExecuteReader();

            List<CadastroPizzaDTO> Atualiza = new List<CadastroPizzaDTO>();

            if(DR.HasRows)
            {

                while(DR.Read())
                {
                    CadastroPizzaDTO objCadastro = new CadastroPizzaDTO();


                    objCadastro.Nome = Convert.ToString(DR["NM_PIZZA"]);
                    objCadastro.Valor= Convert.ToSingle(DR["VALOR_PIZZA"]);
                    objCadastro.Id = Convert.ToInt32(DR["ID_PIZZA"]);



                    Atualiza.Add(objCadastro);

                }
            }




            return Atualiza;


        }

        public static int ExclusaoPizza(int objExclusao)

        {
            SqlConnection conexao = new SqlConnection();
            conexao.ConnectionString = PizzariaDal.Properties.Settings.Default.ConexaoBD;
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexao;
            comando.CommandText = "Delete TB_PIZZA WHERE ID_PIZZA = @IdPizza";
            comando.Parameters.Add("IdPizza", SqlDbType.Int).Value = objExclusao;
            conexao.Open();

            return comando.ExecuteNonQuery();



        }

        public static CadastroPizzaDTO PesquisaPizza (int CodigoPizza)


        {

            SqlConnection conexao = new SqlConnection();
            conexao.ConnectionString = PizzariaDal.Properties.Settings.Default.ConexaoBD;
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexao;
            comando.CommandText = "Select ID_PIZZA, NM_PIZZA,VALOR_PIZZA FROM TB_PIZZA where ID_PIZZA = @Id";
            comando.Parameters.Add("Id", SqlDbType.VarChar).Value = CodigoPizza;
            
            conexao.Open();

            SqlDataReader DR = comando.ExecuteReader();

            CadastroPizzaDTO objPesquisa = new CadastroPizzaDTO();

            if (DR.HasRows)
            {

                while (DR.Read())
                {
                   


                    objPesquisa.Nome = Convert.ToString(DR["NM_PIZZA"]);
                    objPesquisa.Valor = Convert.ToSingle(DR["VALOR_PIZZA"]);
                    objPesquisa.Id = Convert.ToInt32(DR["ID_PIZZA"]);

                }
            }




            return objPesquisa;



        }


        public static void UpdatePizza(CadastroPizzaDTO CodigoPizza)

        {
            SqlConnection conexao = new SqlConnection();
            conexao.ConnectionString = PizzariaDal.Properties.Settings.Default.ConexaoBD;
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexao;
            comando.CommandText = "uPDATE TB_PIZZA SET NM_PIZZA = @Nome , VALOR_PIZZA = @Valor where ID_PIZZA = @Id";
            comando.Parameters.Add("Id", SqlDbType.Int).Value = CodigoPizza.Id;
            comando.Parameters.Add("Nome", SqlDbType.VarChar).Value = CodigoPizza.Nome;
            comando.Parameters.Add("Valor", SqlDbType.Float).Value = CodigoPizza.Valor;


            conexao.Open();

            comando.ExecuteNonQuery();



        }

    }
}
