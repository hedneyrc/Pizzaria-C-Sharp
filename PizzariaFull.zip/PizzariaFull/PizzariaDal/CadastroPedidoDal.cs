﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PizzariaDTO;
using System.Data.SqlClient;
using System.Data;


namespace PizzariaDal
{
    public class CadastroPedidoDal
    {
        public static int InserirPedido(CadastroPedidoDTO objCadastro)
        {
            SqlConnection conexao = new SqlConnection();
            conexao.ConnectionString = PizzariaDal.Properties.Settings.Default.ConexaoBD;
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexao;
            comando.CommandText = "Insert TB_PEDIDO(NmCliente,TelCliente,EndCliente,NmPizza,NmBebida,VlPizza,VlBebida,VlTotal) values (@NmCliente,@TelCliente,@EndCliente,@NmPizza,@NmBebida,@VlPizza,@VlBebida,@VlTotal)";
            comando.Parameters.Add("NmCliente", SqlDbType.VarChar).Value = objCadastro.NomePedido;
            comando.Parameters.Add("TelCliente", SqlDbType.VarChar).Value = objCadastro.TelefonePedido;
            comando.Parameters.Add("EndCliente", SqlDbType.VarChar).Value = objCadastro.EnderecoPedido;
            comando.Parameters.Add("NmPizza", SqlDbType.VarChar).Value = objCadastro.NomePizza;
            comando.Parameters.Add("NmBebida", SqlDbType.VarChar).Value = objCadastro.NomeBebida;
            comando.Parameters.Add("VlPizza", SqlDbType.Float).Value = objCadastro.ValorPizza;
            comando.Parameters.Add("VlBebida", SqlDbType.Float).Value = objCadastro.ValorBebida;
            comando.Parameters.Add("VlTotal", SqlDbType.Float).Value = objCadastro.ValorFinal;

            conexao.Open();

            return comando.ExecuteNonQuery();



        }

        public static List<CadastroPedidoDTO> AtualizaPedido()
        {
            SqlConnection conexao = new SqlConnection();
            conexao.ConnectionString = PizzariaDal.Properties.Settings.Default.ConexaoBD;
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexao;
            comando.CommandText = "Select NmCliente, TelCliente, EndCliente, NmPizza, NmBebida, VlPizza, VlBebida, VlTotal FROM TB_PEDIDO";
            conexao.Open();

            SqlDataReader DR = comando.ExecuteReader();

            List<CadastroPedidoDTO> ConsultaPedido = new List<CadastroPedidoDTO>();

            if(DR.HasRows)
            {

                while(DR.Read())
                {

                    CadastroPedidoDTO Consulta = new CadastroPedidoDTO();

                    Consulta.NomePedido = Convert.ToString(DR["NmCliente"]);
                    Consulta.TelefonePedido = Convert.ToString(DR["TelCliente"]);
                    Consulta.EnderecoPedido = Convert.ToString(DR["EndCliente"]);
                    Consulta.NomePizza = Convert.ToString(DR["NmPizza"]);
                    Consulta.NomeBebida = Convert.ToString(DR["NmBebida"]);
                    Consulta.ValorPizza = Convert.ToSingle(DR["VlPizza"]);
                    Consulta.ValorBebida = Convert.ToSingle(DR["VlBebida"]);
                    Consulta.ValorFinal = Convert.ToSingle(DR["VlTotal"]);


                    ConsultaPedido.Add(Consulta);



                }
            }

           



            return ConsultaPedido;

        }

    }

}
